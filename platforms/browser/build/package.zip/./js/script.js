$(document).ready(function(){
   $("#a_button").click(function(){
      $("#hidden_text").toggle(300); 
   });
});